﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : ScriptableObject
{
    private string ItemName;
    public Sprite Icon;
}
