﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : Movement
{
    [SerializeField] private int moveRange = 2; // The amount of tiles this character can move. INTENDED TO BE CONVERTED TO BE HELD IN A STATS SCRIPT
    [SerializeField] private Sprite availTileSprite = null; // The sprite that should display for where the character can move
    [SerializeField] private string availTileSortLayer = "VisualTile"; // The sorting layer the visual range tile should be on
    private bool amSelected;    // Whether or not the player has selected this character
    private GameObject rangeVisualParent;   // The gameObject with a transform that is the parent of the visualization tiles
    List<Node> validMoveNodes;  // The nodes that this character can move to. Recalculated frequently

    // Called before the first frame
    private void Start()
    {
        Initialize(CharacterType.Ally); // Initialize all the normal variables
        amSelected = false;
        validMoveNodes = null;
    }

    // Update is called once per frame
    private void Update()
    {
        // If this character has not yet moved
        if (!hasMoved)
        {
            // If I should be moving. Transition is handled by MovementController
            if (transition)
            {
                Move();
            }
            // If I shouldnt be moving, accept input
            else
            {
                // If I have been chosen to move
                if (amSelected)
                {
                    // When the player tries to move
                    if (Input.GetMouseButtonDown(0))
                    {
                        Vector3 pos = MouseToGridPoint();

                        Node endNode = moveContRef.GetNodeAtPosition(pos);
                        // Make sure it exists
                        if (endNode != null)
                        {
                            bool amCloseEnough = false; // Assume its too far away
                            foreach (Node node in validMoveNodes)
                            {
                                // If its close enough, set it as so and break
                                if (endNode == node)
                                {
                                    amCloseEnough = true;
                                    break;
                                }
                            }

                            // If the specified node is close enough
                            if (amCloseEnough)
                            {
                                Deselect(); // Hide the visuals before moving
                                moveContRef.MoveRequest(pos, this);
                            }
                            // If the node is too far away, it means the player clicked off where they could select, so deselect their active character
                            else
                            {
                                Debug.Log("I cannot move there");
                                Deselect();
                            }
                        }
                        // If there is no node, it means the player clicked off where they could select, so deselect their active character
                        else
                        {
                            Debug.Log("There is no node there");
                            Deselect();
                        }
                    }
                }
                // If I have not yet been chosen, look for if I am being clicked on
                else
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        Vector3Int pos = MouseToGridPoint();
                        // If the player clicked on this character, show the available moveTiles and consider this character selected
                        if (this.gameObject.transform.position == pos)
                        {
                            Select();
                        }
                    }
                }
            }
        }
    }

    // Puts the mouse location into the world location
    private Vector3Int MouseToGridPoint()
    {
        Vector3 pos = Input.mousePosition;
        pos.z = 20;
        pos = Camera.main.ScreenToWorldPoint(pos);

        // Assumes the grid is set up so that the coordinates are integers and that the player is on the grid
        return new Vector3Int(Mathf.RoundToInt(pos.x), Mathf.RoundToInt(pos.y), 0);
    }

    // Make the character selected and show the tiles
    private void Select()
    {
        // Find the node that the player is on
        Node startNode = moveContRef.GetNodeAtPosition(this.gameObject.transform.position);
        // See if it exists
        if (startNode == null)
        {
            Debug.Log(this.name + " is not on a valid node");
        }
        else
        {
            // Get the available nodes for the player to move to
            validMoveNodes = moveContRef.GetValidMovementNodes(startNode, moveRange, WhatAmI);
            CreateRangeVisuals();
            amSelected = true;
            rangeVisualParent.SetActive(true);
        }
    }

    // Make the character selected and show the tiles
    private void Deselect()
    {
        amSelected = false;
        rangeVisualParent.SetActive(false);
    }

    // Generates the visual tiles for the range
    private void CreateRangeVisuals()
    {
        // Destroy the last visuals, they are probably inaccurate now
        Destroy(rangeVisualParent);
        // Recreate it again
        rangeVisualParent = new GameObject("RangeVisualParent");
        rangeVisualParent.transform.parent = this.gameObject.transform;
        rangeVisualParent.transform.localPosition = Vector3.zero;
        rangeVisualParent.SetActive(false);

        // If there is not already a beginning tile
        if (rangeVisualParent.transform.childCount < 1)
        {
            CreateSingleVisualTile(0, 0, rangeVisualParent.transform); // Make the first tile under the character
        }
        for (int i = 1; i <= moveRange; ++i)
        {
            // Create a new child to serve as the parent for all the tiles about to be made
            GameObject tilesParent = new GameObject("VisualTile" + i + " Parent");
            tilesParent.transform.parent = rangeVisualParent.transform;
            tilesParent.transform.localPosition = Vector3.zero;

            Vector2Int placementPos = new Vector2Int(i, 0);
            // Go down, left
            while (placementPos.x > 0)
            {
                CreateSingleVisualTile(placementPos.x, placementPos.y, tilesParent.transform);
                placementPos.x -= 1;
                placementPos.y -= 1;
            }
            // Go up, left
            while (placementPos.y < 0)
            {
                CreateSingleVisualTile(placementPos.x, placementPos.y, tilesParent.transform);
                placementPos.x -= 1;
                placementPos.y += 1;
            }
            // Go up, right
            while (placementPos.x < 0)
            {
                CreateSingleVisualTile(placementPos.x, placementPos.y, tilesParent.transform);
                placementPos.x += 1;
                placementPos.y += 1;
            }
            // Go down, right
            while (placementPos.y > 0)
            {
                CreateSingleVisualTile(placementPos.x, placementPos.y, tilesParent.transform);
                placementPos.x += 1;
                placementPos.y -= 1;
            }
        }
    }

    // Creates a single visual tile
    // x and y are the local position of the tile
    private void CreateSingleVisualTile(int x, int y, Transform parent)
    {
        // Test if we should really create this new tile by seeing if there is a tile there
        Node testNode = moveContRef.GetNodeAtPosition(new Vector2(Mathf.RoundToInt(this.transform.position.x + x), Mathf.RoundToInt(this.transform.position.y + y)));
        if (!(validMoveNodes.Contains(testNode)))
        {
            return;
        }

        // Create the tile, set it as a child of rangeVisualParent, and place it in a localPosition determined by the passed in values
        GameObject newTile = new GameObject("RangeVisual" + x + " " + y);
        newTile.transform.parent = parent;
        newTile.transform.localPosition = new Vector2(x, y);
        // Attach a sprite renderer to the object, put the correct sprite on it, and place it in the correct sorting layer
        SpriteRenderer sprRend = newTile.AddComponent<SpriteRenderer>();
        sprRend.sprite = availTileSprite;
        sprRend.sortingLayerName = availTileSortLayer;
    }
}
