﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    [SerializeField] private float speed = 4;   // How fast the character animation should move
    protected MovementController moveContRef = null;   // Reference to the MovementController Script
    protected bool transition;  // bool that controls the actual translating of the object
    private Animator animRef;   // Reference to the animator on this object
    /** Some notes about the animator
     * There must exist a integer variable known as MoveState on the animator
     * MoveState = 0 means walk forward
     * MoveState = 1 means walk horizontally
     * MoveState = 2 means walk backward
     * MoveState = -1 means nothing. It is the default state
     * MoveState = -2 means stop moving.
     */
    private SpriteRenderer sprRef;  // Reference to the srite renderer on this object
    private bool doneTransx;    // Whether this is done transitioning in the x
    private bool doneTransy;    // Whether this is done transitioning in the y
    private Node currentNode;   // The node this object wants to move to next
    public bool hasMoved;       // Whether the character has moved yet or not
    private CharacterType whatAmI;  // What type of character this is
    public CharacterType WhatAmI
    {
        get { return whatAmI; }
    }

    // Set References
    private void Awake()
    {
        animRef = this.GetComponent<Animator>();
        sprRef = this.GetComponent<SpriteRenderer>();
        moveContRef = GameObject.FindWithTag("GameController").GetComponent<MovementController>();
    }

    // Start is called from its children
    protected void Initialize(CharacterType charT)
    {
        transition = false;
        doneTransx = true;
        doneTransy = true;
        hasMoved = false;
        // Set the currentNode to the node I am on and what I am
        currentNode = moveContRef.GetNodeAtPosition(new Vector2(Mathf.Round(this.transform.position.x), Mathf.Round(this.transform.position.y)));
        whatAmI = charT;    // Set what character type this script is attached to
        currentNode.occupying = whatAmI; // Set what is on the tile
    }

    // Called when this has been given the okay to move.
    // Starts the movement of the character
    public void AllowMove()
    {
        // Assumes transToMove is on the grid
        currentNode = moveContRef.GetNodeAtPosition(new Vector2(Mathf.RoundToInt(this.gameObject.transform.position.x), Mathf.RoundToInt(this.gameObject.transform.position.y)));
        if (currentNode != null)
        {
            //Debug.Log("currentNode at " + currentNode.position + " wants to move to the node at " + currentNode.whereToGo.position);
            doneTransx = false;
            doneTransy = false;
            transition = true;
        }
        else
        {
            Debug.Log("That node does not exist");
        }
    }

    // Moves the object slightly towards the next tile.
    public void Move()
    {
        // If the currentNode exists
        if (currentNode.whereToGo != null)
        {
            // If not finished moving in the x
            if (!doneTransx)
            {
                // While this is left of the node it wants to get to
                if (currentNode.whereToGo.position.x - this.gameObject.transform.position.x > 0.1f)
                {
                    animRef.SetInteger("MoveState", 1);
                    sprRef.flipX = false;
                    this.gameObject.transform.position += Vector3.right * speed * Time.deltaTime;
                }
                // While this is right of the node it wants to get to
                else if (this.gameObject.transform.position.x - currentNode.whereToGo.position.x > 0.1f)
                {
                    animRef.SetInteger("MoveState", 1);
                    sprRef.flipX = true;
                    this.gameObject.transform.position += Vector3.left * speed * Time.deltaTime;
                }
                else
                {
                    this.gameObject.transform.position = new Vector3(Mathf.RoundToInt(currentNode.whereToGo.position.x), Mathf.RoundToInt(this.gameObject.transform.position.y), this.gameObject.transform.position.z);
                    doneTransx = true;
                }
            }

            // If not finished moving in the y
            if (!doneTransy)
            {
                // While the node this wants to get to is above where this is
                if (currentNode.whereToGo.position.y - this.gameObject.transform.position.y > 0.1f)
                {
                    sprRef.flipX = false;
                    animRef.SetInteger("MoveState", 2);
                    this.gameObject.transform.position += Vector3.up * speed * Time.deltaTime;
                }
                // While the node this wants to get to is below where this is
                else if (this.gameObject.transform.position.y - currentNode.whereToGo.position.y > 0.1f)
                {
                    sprRef.flipX = false;
                    animRef.SetInteger("MoveState", 0);
                    this.gameObject.transform.position += Vector3.down * speed * Time.deltaTime;
                }
                else
                {
                    this.gameObject.transform.position = new Vector3(Mathf.RoundToInt(this.gameObject.transform.position.x), Mathf.RoundToInt(currentNode.whereToGo.position.y), this.gameObject.transform.position.z);
                    doneTransy = true;
                }
            }

            // Once I have reached the node I was trying to get to
            if (doneTransx && doneTransy)
            {
                // If that node is the last node, stop moving
                if (currentNode.whereToGo == currentNode)
                {
                    currentNode.occupying = whatAmI;    // Set the node I am ending on to occupied with my type
                    animRef.SetInteger("MoveState", -2);
                    transition = false;
                    currentNode = null;
                    hasMoved = true;
                    //Debug.Log("Reached destination");
                }
                // Otherwise, find the next node
                else
                {
                    currentNode.occupying = CharacterType.None; // Make the node I just came from have no character on it, so that others can pass through it
                    animRef.SetInteger("MoveState", -1);
                    currentNode = currentNode.whereToGo;
                    doneTransx = false;
                    doneTransy = false;
                }
            }
        }
        // If it doesn't exist, we shouldn't be moving
        else
        {
            transition = false;
            Debug.Log("Current Tile does not exist");
        }
    }
}