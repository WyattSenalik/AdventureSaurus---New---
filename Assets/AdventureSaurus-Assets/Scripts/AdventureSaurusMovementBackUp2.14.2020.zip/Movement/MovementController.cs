﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementController : MonoBehaviour
{
    [SerializeField] private Transform wallsParent = null;  // The parent of all walls. These walls must be positioned such that 
    [SerializeField] private Vector2 minLoc = new Vector2(0, 0);    // The bottom left of the grid
    [SerializeField] private Vector2 maxLoc = new Vector2(0, 0);    // The top right of the grid
    [SerializeField] private float nodeSize = 1;    // The size of the node
    private List<List<Node>> nodeGrid;  // A grid of the nodes. Each element is a row of the nodes

    // Initialize all the Nodes' variables
    // Assumes the nodes in nodesParent are sorted in such a way that all nodes in the same row sequentially appear
    // We do this in Awake so that characters can access it in Start
    private void Awake()
    {
        // Step 1: Fill the nodeGrid with nodes that span from minLoc to maxLoc
        nodeGrid = new List<List<Node>>();  // Initialize the nodeGrid
        int currentRow = 0;
        for (float i = minLoc.y; i <= maxLoc.y; i += nodeSize)
        {
            nodeGrid.Add(new List<Node>()); // Add the next row
            for (float j = minLoc.x; j <= maxLoc.x; j += nodeSize)
            {
                nodeGrid[currentRow].Add(new Node(new Vector2(j, i)));  // Add a node to the current row
            }
            currentRow += 1;
        }

        // Step 2: Make the nodes at the locations shared by the children of WallsParent be impassible
        foreach (Transform wall in wallsParent)
        {
            /* To make this work with the CreateBoard function, find out what the wall sprite is and test if the wall has that sprite, then do whats below */

            // Check if the wall is within the grid
            if (wall.position.x > maxLoc.x || wall.position.x < minLoc.x || wall.position.y > maxLoc.y || wall.position.y < minLoc.y)
            {
                Debug.Log(wall.name + " is not within the grid");
            }
            else
            {
                // Determine the location of this wall in on the grid
                Vector2Int wallIndices = new Vector2Int(Mathf.RoundToInt(wall.position.x - minLoc.x), Mathf.RoundToInt(wall.position.y - minLoc.y));
                nodeGrid[wallIndices.y][wallIndices.x].occupying = CharacterType.Wall;
            }
        }
        
    }

    // Called when something tries to move. Finds the node at pos and calls RecursivePathing to update whereToGo variables
    // requester is the thing that requested to move
    // distance is how far the requester is able to move. We will not allow the requester to move if they are too far from the node
    public void MoveRequest(Vector2 pos, Movement requester)
    {
        Node desiredNode = GetNodeAtPosition(pos);
        if (desiredNode != null)
        {
            //Debug.Log("Resetting Pathing");
            ResetPathing(); // Reset the previous pathing information
            //Debug.Log("Setting first desired node");
            desiredNode.whereToGo = desiredNode;    // Set the desired node's whereToGo to be itself, so we know it is the desired node
            //Debug.Log("Determining Pathing");
            // Update all the whereToGo references. If successful, then tell the requester to move
            if (Pathing(desiredNode, requester.WhatAmI))
            {
                //Debug.Log("Letting the requester move");
                requester.AllowMove();  // Tells thee who request that they are permitted to move
            }
           
        }
        else
        {
            Debug.Log("No node at the entered position of " + pos);
        }
    }

    /// <summary>
    /// Should always be called before Pathing. Resets the whereToGo variable on each node that determines where it should go
    /// </summary>
    private void ResetPathing()
    {
        foreach (List<Node> row in nodeGrid)
        {
            foreach (Node node in row)
            {
                node.whereToGo = null;
            }
        }
    }

    // First call should contain the ndoe at the location that is desired to reach
    // current is the node that we are trying to get to
    private bool Pathing(Node current, CharacterType requestType)
    {
        // Make sure the node I want to go to is not occupied
        if (current.occupying == CharacterType.None)
        {
            List<Node> InProgressNodes = new List<Node>();

            InProgressNodes.Add(current);

            while (InProgressNodes.Count != 0)
            {
                int amountNodes = InProgressNodes.Count;
                //Debug.Log("There are " + amountNodes + " nodes in InProgressNodes");

                for (int i = 0; i < amountNodes; ++i)
                {
                    //Debug.Log("Telling adjacent nodes to come to " + InProgressNodes[i].position);
                    // Check above node
                    Vector2 testPos = new Vector2(InProgressNodes[i].position.x, InProgressNodes[i].position.y + 1);
                    PathingTestNode(testPos, InProgressNodes, i, requestType);

                    // Check left node
                    testPos = new Vector2(InProgressNodes[i].position.x - 1, InProgressNodes[i].position.y);
                    PathingTestNode(testPos, InProgressNodes, i, requestType);

                    // Check right node
                    testPos = new Vector2(InProgressNodes[i].position.x + 1, InProgressNodes[i].position.y);
                    PathingTestNode(testPos, InProgressNodes, i, requestType);

                    // Check down node
                    testPos = new Vector2(InProgressNodes[i].position.x, InProgressNodes[i].position.y - 1);
                    PathingTestNode(testPos, InProgressNodes, i, requestType);
                }
                for (int i = 0; i < amountNodes; ++i)
                {
                    InProgressNodes.RemoveAt(0);
                }
            }
            return true;    // Was a valid spot to move
        }
        else
        {
            Debug.Log("You cannot move here");
            return false;   // Was an invalid node
        }
    }

    // Used to test the current testNode in Pathing
    // testPos is the position of the node being tested
    // InProgressNodes is a reference to the List of Nodes that have not been tested yet, that need to be
    // i is the index of the InProgressNodes we are testing
    // requestType is the CharacterType the requester is. They can move through their allys
    private void PathingTestNode(Vector2 testPos, List<Node> InProgressNodes, int i, CharacterType requestType)
    {
        Node testNode = GetNodeAtPosition(testPos);
        if (testNode != null)
        {
            // If the node I am trying to go to has not already been set
            if (testNode.whereToGo == null)
            {
                // If the node I am trying to go to is not occupied or is toccupied by someone on my team
                if (testNode.occupying == CharacterType.None || testNode.occupying == requestType)
                {
                    testNode.whereToGo = InProgressNodes[i];
                    InProgressNodes.Add(testNode);
                }
            }
        }
    }

    // Returns a list of all the nodes that can be reached from startNode in moveRadius moves or less
    // starNode is the node that we are starting the test from
    // moveRadius is how many nodes the request can move
    // requestType is what kind of Character the requester is
    public List<Node> GetValidMovementNodes(Node startNode, int moveRadius, CharacterType requestType)
    {
        List<Node> validNodes = new List<Node>();   // This list is what will be returned. It is the nodes that can be moved to
        validNodes.Add(startNode);

        List<Node> currentNodes = new List<Node>(); // This list holds the nodes that have yet to be tested for validity
        currentNodes.Add(startNode);

        int depth = 0;  // This is how many iterations of checks we have gone over. Aka, how many tiles have been traversed in one path
        while (depth < moveRadius)
        {
            int amountNodes = currentNodes.Count;
            for (int i = 0; i < amountNodes; ++i)
            {
                // Check above node
                Vector2 testPos = new Vector2(currentNodes[i].position.x, currentNodes[i].position.y + 1);
                ValidTestNode(testPos, validNodes, currentNodes, requestType);

                // Check left node
                testPos = new Vector2(currentNodes[i].position.x - 1, currentNodes[i].position.y);
                ValidTestNode(testPos, validNodes, currentNodes, requestType);

                // Check right node
                testPos = new Vector2(currentNodes[i].position.x + 1, currentNodes[i].position.y);
                ValidTestNode(testPos, validNodes, currentNodes, requestType);

                // Check down node
                testPos = new Vector2(currentNodes[i].position.x, currentNodes[i].position.y - 1);
                ValidTestNode(testPos, validNodes, currentNodes, requestType);
                
            }
            // Remove the nodes that have already been iterated over
            for (int i = 0; i < amountNodes; ++i)
            {
                currentNodes.RemoveAt(0);
            }
            ++depth;
        }
        return validNodes;
    }

    // Used to test the current testNode in GetValidMovementNodes
    // testPos is the position of the node being tested
    // validNodes is a reference to the List of Nodes that have been deemed valid to move to
    // currentNodes is a reference to the List of Nodes that still need to be tested
    // requestType is the CharacterType the requester is. They can move through their allys
    private void ValidTestNode(Vector2 testPos, List<Node> validNodes, List<Node> currentNodes, CharacterType requestType)
    {
        Node testNode = GetNodeAtPosition(testPos);
        if (testNode != null)
        {
            // If the node is not occupied, I can move there
            if (testNode.occupying == CharacterType.None)
            {
                validNodes.Add(testNode);
                currentNodes.Add(testNode);
            }
            // If it is occupied by someone on my team, I can't move there, but I can move past there
            else if (testNode.occupying == requestType)
            {
                currentNodes.Add(testNode);
            }
        }
    }

    // Returns the node at the specified location
    public Node GetNodeAtPosition(Vector2 pos)
    {
        foreach (List<Node> row in nodeGrid)
        {
            foreach (Node node in row)
            {
                if (node.position == pos)
                {
                    return node;
                }
            }
        }
        return null;    // If we did not find one there
    }

    // For testing, print the nodeGrid
    private void PrintGrid()
    {
        foreach (List<Node> row in nodeGrid)
        {
            string infoToPrint = "";
            foreach (Node node in row)
            {
                infoToPrint += "(" + node.position.x.ToString() + ", " + node.position.y.ToString() + ") = " + node.occupying + ";  ";
            }
            Debug.Log(infoToPrint);
        }
    }
}
