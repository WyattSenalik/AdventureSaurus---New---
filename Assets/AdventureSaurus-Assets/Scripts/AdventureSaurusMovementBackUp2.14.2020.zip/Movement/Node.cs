﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CharacterType { None, Wall, Ally, Enemy};

public class Node
{
    public Vector2 position;    // The position of the node in 2D space
    public Node[] adjacent; // The nodes adjacent to this node
    public Node whereToGo;  // The node that a unit on this node should move to if they want to get to the desired location
    public CharacterType occupying; // What is currently on this tile

    public Node(Vector2 _pos_)
    {
        position = _pos_;
        adjacent = new Node[4];
        whereToGo = null;
        occupying = CharacterType.None;
    }
}
